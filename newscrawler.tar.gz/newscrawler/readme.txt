celery -A newscrawler worker -l info -B
python manage.py runserver
