from __future__ import absolute_import
from .mod_celery import app as celery_app